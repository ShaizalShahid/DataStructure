import java.util.Arrays;
public class ArrayInsertion {
    public static void main(String[] args) {
        int[] arr = new int[10];
        arr[0] = 10;
        arr[1] = 20;
        arr[2] = 30;
        arr[3] = 40;
        int currentSize = 4;
        System.out.println("Original Array: " + Arrays.toString(Arrays.copyOf(arr, currentSize)));
        int elementToInsert = 25;
        int index = 2;
        for (int i = currentSize; i > index; i--) {
            arr[i] = arr[i - 1];
        }
        arr[index] = elementToInsert;
        currentSize++;
        System.out.println("Array after insertion: " + Arrays.toString(Arrays.copyOf(arr, currentSize)));
    }
}