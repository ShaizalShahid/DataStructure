import java.util.Arrays;
public class ArrayDeletion {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        int currentSize = arr.length;
        System.out.println("Original Array: " + Arrays.toString(Arrays.copyOf(arr, currentSize)));
        int indexToDelete = 2;
        for (int i = indexToDelete; i < currentSize - 1; i++) {
            arr[i] = arr[i + 1];
        }
        currentSize--;
        System.out.println("Array after deletion: " + Arrays.toString(Arrays.copyOf(arr, currentSize)));
    }
}